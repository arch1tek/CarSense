package org.example;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.rekognition.AmazonRekognition;
import com.amazonaws.services.rekognition.AmazonRekognitionClientBuilder;
import com.amazonaws.services.rekognition.model.*;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.ObjectListing;
//import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.amazonaws.services.rekognition.model.S3Object;
import org.example.SQShandler;

public class Main {
    public static void main(String[] args) {
        SQShandler sqshandler = new SQShandler();
        String accessKey = "AKIAWYQPNBJEBVMGP5PC";
        String secretKey = "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";
        String bucketName = "njit-cs-643";
        double minConfidence = 90.0;

        // Initialize AWS S3 and Rekognition clients
        AWSCredentials credentials = new BasicAWSCredentials(accessKey, secretKey);
        AmazonS3 s3Client = AmazonS3ClientBuilder.standard()
                .withCredentials(new AWSStaticCredentialsProvider(credentials))
                .withRegion("us-east-1")
                .build();
        AmazonRekognition rekognitionClient = AmazonRekognitionClientBuilder.standard()
                .withCredentials(new AWSStaticCredentialsProvider(credentials))
                .withRegion("us-east-1")
                .build();

        while (true){
            String res = sqshandler.receiveMessage();
            if(res.equals("-1")){
                System.out.println("Quit");
                return;
            }
            DetectTextRequest request = new DetectTextRequest()
                    .withImage(new Image()
                            .withS3Object(new S3Object()
                                    .withName(res).withBucket(bucketName)));
            DetectTextResult result = rekognitionClient.detectText(request);
            for (TextDetection text : result.getTextDetections()){
                System.out.println(text.getDetectedText());
            }

        }

       }
}