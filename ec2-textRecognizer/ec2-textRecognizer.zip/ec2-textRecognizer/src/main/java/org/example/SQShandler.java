package org.example;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSClientBuilder;
import com.amazonaws.services.sqs.model.*;

public class SQShandler {
    private String accessKey = "AKIAWYQPNBJEBVMGP5PC";
    private String secretKey = "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";
    private String queueUrl = "https://sqs.us-east-1.amazonaws.com/464962521672/aws-project-101-queue.fifo";

    private AWSCredentials credentials = new BasicAWSCredentials(accessKey, secretKey);
    private AmazonSQS sqsClient = AmazonSQSClientBuilder.standard()
            .withCredentials(new AWSStaticCredentialsProvider(credentials))
            .withRegion("us-east-1") // Replace with the appropriate AWS region
            .build();
    public String receiveMessage() {
        ReceiveMessageRequest receiveMessageRequest = new ReceiveMessageRequest()
                .withQueueUrl(queueUrl)
                .withMaxNumberOfMessages(1)
                .withWaitTimeSeconds(3);

        ReceiveMessageResult receiveMessageResult = sqsClient.receiveMessage(receiveMessageRequest);

        for (Message message : receiveMessageResult.getMessages()) {
            String messageBody = message.getBody();



            System.out.println("Received message: " + messageBody);

            // Delete the message from the queue to acknowledge receipt
            sqsClient.deleteMessage(queueUrl, message.getReceiptHandle());
            return messageBody;
        }
        // Create a request to send a message
        return "";

        // Send the message

        // Print the message ID
    }
}

